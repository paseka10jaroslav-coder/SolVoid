# Privacy-Zero: Solana Privacy Hygiene Scanner

> ⚠️ **IMPORTANT**: This is a **LEAK DETECTION** tool, NOT a privacy solution.
> It identifies privacy issues in your transactions - it does NOT make you anonymous.

## What This Tool Does

Privacy-Zero scans Solana transactions and identifies potential privacy leaks:

- **Identity Leaks**: When your wallet address appears in transaction data
- **Metadata Leaks**: Memo programs, logging, amounts exposed
- **State Leaks**: Your identity written to third-party account data
- **Order Flow Exposure**: MEV/sandwich attack vulnerability
- **CPI Linkage**: Identity propagation through cross-program calls

## What This Tool Does NOT Do

❌ **Does NOT make transactions private**
❌ **Does NOT hide your identity on-chain**
❌ **Does NOT encrypt your data**
❌ **Does NOT provide anonymity**

All Solana transactions are public and permanent. This tool helps you understand what you're exposing.

## Installation

```bash
npm install @org/privacy-zero
```

## Quick Start

### CLI Usage

```bash
# Scan a transaction by signature
npx privacy-scan 5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc...

# Scan with custom RPC (recommended for privacy)
npx privacy-scan <signature> --rpc https://your-private-rpc.com

# Enable all forensics
npx privacy-scan <signature> --enterprise

# Scan from JSON file
npx privacy-scan ./transaction.json
```

### SDK Usage

```typescript
import { PrivacyZeroClient } from '@org/privacy-zero';

const client = new PrivacyZeroClient({
    rpcUrl: process.env.RPC_URL || 'https://api.mainnet-beta.solana.com',
    modules: {
        mev: true,
        semantic: true,
        compliance: true
    }
});

const report = await client.scan(transactionJson);
console.log(`Privacy Score: ${report.privacyScore}/100`);
console.log(`Leaks Found: ${report.unacceptedLiabilities.length}`);
```

## For Actual Privacy

If you want actual privacy (not just leak detection), use these tools:

### 1. MEV Protection (Jito)
Prevents front-running and sandwich attacks:

```typescript
import { searcherClient } from '@jito-foundation/jito-ts';

// Send transaction through Jito's private mempool
const bundle = await client.sendBundle([signedTx]);
```

### 2. Amount Privacy (Token-2022)
Hides transfer amounts (addresses still visible):

```typescript
import { ConfidentialTokenManager } from '@org/privacy-zero';

const manager = new ConfidentialTokenManager(connection);
const depositIx = await manager.createDepositPublicToPrivate(
    mint, tokenAccount, owner, amount
);
```

### 3. Full Privacy (Light Protocol)
Hides sender, receiver, and amounts:

```typescript
import { LightProtocolManager } from '@org/privacy-zero';

const manager = new LightProtocolManager(rpcUrl);
const shieldIx = await manager.createShieldSolInstruction(
    userPubkey, amountLamports
);
```

## Privacy Manifest

Create a `privacy-manifest.json` to manage accepted risks:

```json
{
    "version": 1,
    "owners": {
        "privacy": ["privacy-team@company.com"],
        "security": ["security-team@company.com"]
    },
    "waivers": [
        {
            "id": "W-2024-001",
            "leak_type": "identity",
            "scope": "program:Jupiter",
            "justification": "DEX interaction requires identity link",
            "approved_by": "security@company.com",
            "expires": "2025-01-01"
        }
    ]
}
```

## Threat Profiles

Choose a profile that matches your security needs:

```bash
# Standard (balanced)
npx privacy-scan <sig> --profile standard

# MEV Protection (high order-flow weight)
npx privacy-scan <sig> --profile mev-protection

# Regulatory Compliance (GDPR/CCPA focus)
npx privacy-scan <sig> --profile regulatory-compliance

# Counterparty Evasion (hiding intent)
npx privacy-scan <sig> --profile counterparty-evasion
```

## API Reference

### PrivacyZeroClient

```typescript
interface PrivacyZeroConfig {
    rpcUrl: string;
    modules?: {
        mev?: boolean;      // Order flow analysis
        semantic?: boolean;  // IDL-based deep analysis
        compliance?: boolean; // Regulatory checks
    };
}

class PrivacyZeroClient {
    scan(tx: TransactionJSON, options?: ScanOptions): Promise<GovernanceResult>;
}
```

### GovernanceResult

```typescript
interface GovernanceResult {
    status: "SURFACE_SCAN_PASSED" | "RISK_ACCEPTED" | "REGRESSION";
    privacyScore?: number; // 0-100
    acceptedLiabilities: { leak: Leak; waiver: Waiver }[];
    unacceptedLiabilities: { leak: Leak; reason: string }[];
    remediationHints: string[];
}
```

## Security Considerations

### RPC Privacy
When using this tool, your RPC provider can see:
- Your IP address
- All transactions you're querying
- Timing patterns of your queries

Always use a private RPC or run your own node for sensitive operations.

### No Magic Solutions
There is no way to make a Solana transaction truly "private" after it's been submitted to the public mempool. This tool helps you:
1. Understand what you're exposing
2. Make informed decisions
3. Use proper privacy tools BEFORE submitting

### Removed Features
The "obfuscation" features that were previously in this tool have been **removed** because they provided false privacy:
- Session keys required funding from main wallet (traceable)
- No actual cryptographic privacy
- Drew attention with unusual patterns

## Troubleshooting

### "Connection refused" error
- Check your RPC endpoint is accessible
- Try: `privacy-scan <sig> --rpc https://api.mainnet-beta.solana.com`

### "Transaction not found"
- Transaction may be too old (>90 days)
- Verify signature is correct
- Check you're on correct cluster (mainnet/devnet)

### High memory usage
- Large transactions with many accounts can use significant memory
- This is normal for complex DeFi transactions

### Rate limiting
- Public RPCs have rate limits
- Use your own RPC or add delays if scanning continuously

## FAQ

**Q: Does this make my transactions private?**
A: No. This is a scanner that detects leaks. For actual privacy, use Light Protocol or Token-2022 Confidential Transfers.

**Q: Can I use this in CI/CD?**
A: Yes. Exit code is non-zero if leaks are found (REGRESSION state).

**Q: What's the difference between --basic and --enterprise?**
A: Enterprise mode includes binary state scanning, deep semantic analysis, and compliance checks.

**Q: Is this open source?**
A: Yes, MIT licensed.

**Q: How do I report a bug?**
A: Open an issue on GitHub or see [SECURITY.md](SECURITY.md) for vulnerabilities.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

## License

MIT License - See [LICENSE](./LICENSE) for details.

---

**Remember**: On-chain data is permanent and public. Think before you transact.
